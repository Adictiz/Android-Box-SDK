package com.adictiz.sampleappsdkandroid;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.adictiz.box.Box;

/**
 * Created by kevinlefebvre on 15/06/15.
 */
public class BannersListView extends Activity implements View.OnClickListener {

    /****************************************
     * BUILD VIEW
     ***************************************/

    private int _deviceWidth;
    private int _deviceHeight;

    private RelativeLayout _titleBar;
    private TextView _title;

    private TextView _label1;

    private RelativeLayout _bannersListRLayout;

    private Button _returnBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.banners_list_main);

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        _deviceWidth = metrics.widthPixels;
        _deviceHeight = metrics.heightPixels;

        _titleBar = (RelativeLayout) findViewById(R.id.relativeLayout);
        _titleBar.getLayoutParams().height = (int) (_deviceHeight * 0.1);
        _titleBar.getLayoutParams().width = _deviceWidth;

        _title = (TextView) findViewById(R.id.title);
        _title.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));

        _label1 = (TextView) findViewById(R.id.label1);
        _label1.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));

        RelativeLayout.LayoutParams paramsLabel = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        paramsLabel.setMargins(0, (int) (_deviceHeight * .02), 0, 0);
        _label1.setLayoutParams(paramsLabel);

        _bannersListRLayout = (RelativeLayout) findViewById(R.id.bannersList);

        paramsLabel = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        paramsLabel.addRule(RelativeLayout.BELOW, _label1.getId());
        paramsLabel.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
        paramsLabel.setMargins(0, (int) (_deviceHeight * 0.01), 0, 0);
        _bannersListRLayout.setLayoutParams(paramsLabel);

        _returnBtn = (Button) findViewById(R.id.returnBtn);
        _returnBtn.getLayoutParams().width = (int) (_deviceWidth * 0.5);
        _returnBtn.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));
        _returnBtn.setOnClickListener(this);

        /****************************************
         * BOX SDK INTEGRATION
         ***************************************/

        //Displaying a wall of banners
        _bannersListRLayout.addView(Box.getCampaignsListView());
    }

    /****************************************
     * BUILD VIEW (METHOD)
     ***************************************/

    public void onClick(View v) {
        if (v.getId() == _returnBtn.getId()) {
            this.finish();
        }
    }
}