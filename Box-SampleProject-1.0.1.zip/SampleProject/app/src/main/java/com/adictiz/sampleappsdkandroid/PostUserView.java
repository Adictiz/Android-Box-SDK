package com.adictiz.sampleappsdkandroid;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.adictiz.box.BUser;
import com.adictiz.box.Box;
import com.adictiz.box.BoxRequestListener;

/**
 * Created by kevinlefebvre on 13/01/16.
 */
public class PostUserView extends Activity implements View.OnClickListener, BoxRequestListener {

    /****************************************
     * BUILD VIEW
     ***************************************/

    private int _deviceWidth;
    private int _deviceHeight;

    private RelativeLayout _titleBar;
    private TextView _title;

    private TextView _label1;
    private TextView _label2;
    private TextView _label3;

    private EditText _input1;
    private EditText _input2;
    private EditText _input3;

    private Button _returnBtn;
    private Button _submitBtn;

    private BUser _user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.post_user_main);

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        _deviceWidth = metrics.widthPixels;
        _deviceHeight = metrics.heightPixels;

        _titleBar = (RelativeLayout) findViewById(R.id.relativeLayout);
        _titleBar.getLayoutParams().height = (int) (_deviceHeight * 0.1);
        _titleBar.getLayoutParams().width = _deviceWidth;

        _title = (TextView) findViewById(R.id.title);
        _title.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));

        _label1 = (TextView) findViewById(R.id.label1);
        _label1.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));

        _label2 = (TextView) findViewById(R.id.label2);
        _label2.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));

        _label3 = (TextView) findViewById(R.id.label3);
        _label3.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));

        _input1 = (EditText) findViewById(R.id.input1);
        _input1.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));
        _input1.setBackgroundResource(R.drawable.abc_edit_text_material);

        _input2 = (EditText) findViewById(R.id.input2);
        _input2.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));
        _input2.setBackgroundResource(R.drawable.abc_edit_text_material);

        _input3 = (EditText) findViewById(R.id.input3);
        _input3.setBackgroundResource(R.drawable.abc_edit_text_material);
        _input3.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));

        _label1.setLayoutParams(generateLayoutParam(true, false, 0, (int) (_deviceHeight * .02)));
        _label2.setLayoutParams(generateLayoutParam(true, false, _input1.getId(), (int) (_deviceHeight * .02)));
        _label3.setLayoutParams(generateLayoutParam(true, false, _input2.getId(), (int) (_deviceHeight * .02)));
        _input1.setLayoutParams(generateLayoutParam(false, false, _label1.getId(), (int) (_deviceHeight * .02)));
        _input2.setLayoutParams(generateLayoutParam(false, false, _label2.getId(), (int) (_deviceHeight * .02)));
        _input3.setLayoutParams(generateLayoutParam(false, false, _label3.getId(), (int) (_deviceHeight * .02)));

        _submitBtn = (Button) findViewById(R.id.submitBtn);
        _submitBtn.getLayoutParams().width = (int) (_deviceWidth * 0.5);
        _submitBtn.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));
        _submitBtn.setOnClickListener(this);

        _returnBtn = (Button) findViewById(R.id.returnBtn);
        _returnBtn.getLayoutParams().width = (int) (_deviceWidth * 0.5);
        _returnBtn.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));
        _returnBtn.setOnClickListener(this);
    }

    /****************************************
     * BOX SDK CALLBACK
     ***************************************/

    @Override
    public void onPostUserFormSuccess(String s) {

        //Calling a campaign with a box user permit to skip the register form
        Box.showCampaign(MainActivity.campaignID, _user);
    }

    @Override
    public void onPostUserFormFailure(String error) {
        Log.w("SP : SDK BOX", error);
    }

    //NOT USED
    @Override
    public void onGetCampaignsListSuccess(String s) {

    }

    @Override
    public void onGetCampaignsListFailure(String s) {

    }

    @Override
    public void onPostPictureResult(boolean b) {

    }

    @Override
    public void onGetPicturesListSuccess(String s) {

    }

    @Override
    public void onGetPicturesListFailure(String s) {

    }

    /****************************************
     * BUILD VIEW (METHOD)
     ***************************************/

    public RelativeLayout.LayoutParams generateLayoutParam(boolean isMatchParent_w, boolean isMatchParent_h, int idReference, int margin) {

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(isMatchParent_w ? RelativeLayout.LayoutParams.MATCH_PARENT : (int) (_deviceWidth * 0.7),
                isMatchParent_h ? RelativeLayout.LayoutParams.MATCH_PARENT : RelativeLayout.LayoutParams.WRAP_CONTENT);

        if (idReference != 0) {
            params.addRule(RelativeLayout.BELOW, idReference);
            params.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
        }

        params.setMargins(0, margin, 0, 0);

        return params;
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == _returnBtn.getId()) {
            this.finish();
        } else if (v.getId() == _submitBtn.getId()) {

            /****************************************
             * BOX SDK INTEGRATION
             ***************************************/

            _user = new BUser();

            if (_input1.getText().length() == 0) {
                Log.w("SP : SDK BOX", "Error : Firstname is not valid");
                return;
            }

            if (_input2.getText().length() == 0) {
                Log.w("SP : SDK BOX", "Error : Lastname is not valid");
                return;
            }

            if (_input3.getText().length() == 0) {
                Log.w("SP : SDK BOX", "Error : email is not valid");
                return;
            }

            try {
                _user.setFirstname(_input1.getText().toString());
            } catch (Exception e) {
                Log.w("SP : SDK BOX", "Error : Firstname is not valid");
                return;
            }

            try {
                _user.setLastname(_input2.getText().toString());
            } catch (Exception e) {
                Log.w("SP : SDK BOX", "Error : Lastname is not valid");
                return;
            }

            try {
                _user.setEmail(_input3.getText().toString());
            } catch (Exception e) {
                Log.w("SP : SDK BOX", "Error : Email is not valid");
                return;
            }

            if(MainActivity.apiKey.length() == 0){
                Log.w("SP : SDK BOX", "To get your apiKey contact us at contact@adictiz.com");
                return;
            }

            //register the user for a specified campaign
            Box.postUserForm(MainActivity.apiKey, MainActivity.campaignID, _user, this);
        }
    }
}
