package com.adictiz.sampleappsdkandroid;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.adictiz.box.Box;

/**
 * Created by kevinlefebvre on 15/06/15.
 */

public class BannerView extends Activity implements View.OnClickListener {

    /****************************************
     * BUILD VIEW
     ***************************************/

    private int _deviceWidth;
    private int _deviceHeight;

    private RelativeLayout _titleBar;
    private TextView _title;

    private TextView _label1;
    private TextView _label2;
    private TextView _label3;

    private RelativeLayout _banner1;
    private RelativeLayout _banner2;
    private RelativeLayout _banner3;

    private Button _returnBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.banner_main);

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        _deviceWidth = metrics.widthPixels;
        _deviceHeight = metrics.heightPixels;

        _titleBar = (RelativeLayout) findViewById(R.id.relativeLayout);
        _titleBar.getLayoutParams().height = (int) (_deviceHeight * 0.1);
        _titleBar.getLayoutParams().width = _deviceWidth;

        _title = (TextView) findViewById(R.id.title);
        _title.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));

        _label1 = (TextView) findViewById(R.id.label1);
        _label1.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));
        _label2 = (TextView) findViewById(R.id.label2);
        _label2.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));
        _label3 = (TextView) findViewById(R.id.label3);
        _label3.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));

        _banner1 = (RelativeLayout) findViewById(R.id.firstBanner);
        _banner2 = (RelativeLayout) findViewById(R.id.secondBanner);
        _banner3 = (RelativeLayout) findViewById(R.id.thirdBanner);

        _label1.setLayoutParams(generateLayoutParam(true, false, 0, (int) (_deviceHeight * .02)));
        _label2.setLayoutParams(generateLayoutParam(true, false, _banner1.getId(), (int) (_deviceHeight * .02)));
        _label3.setLayoutParams(generateLayoutParam(true, false, _banner2.getId(), (int) (_deviceHeight * .02)));
        _banner1.setLayoutParams(generateLayoutParam(false, false, _label1.getId(), (int) (_deviceHeight * .01)));
        _banner2.setLayoutParams(generateLayoutParam(false, false, _label2.getId(), (int) (_deviceHeight * .01)));
        _banner3.setLayoutParams(generateLayoutParam(false, false, _label3.getId(), (int) (_deviceHeight * .01)));

        _returnBtn = (Button) findViewById(R.id.returnBtn);
        _returnBtn.getLayoutParams().width = (int) (_deviceWidth * 0.5);
        _returnBtn.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));
        _returnBtn.setOnClickListener(this);

        /****************************************
         * BOX SDK INTEGRATION
         ***************************************/

        //Displaying banner with differents parameters
        _banner1.addView(Box.getBannerView());
        _banner2.addView(Box.getBannerView(_deviceWidth / 2, 0, false));
        _banner3.addView((Box.getBannerView(_deviceWidth, 0, true)));
    }

    /****************************************
     * BUILD VIEW (METHODS)
     ***************************************/

    public RelativeLayout.LayoutParams generateLayoutParam(boolean isMatchParent_w, boolean isMatchParent_h, int idReference, int margin) {

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(isMatchParent_w ? RelativeLayout.LayoutParams.MATCH_PARENT : RelativeLayout.LayoutParams.WRAP_CONTENT,
                isMatchParent_h ? RelativeLayout.LayoutParams.MATCH_PARENT : RelativeLayout.LayoutParams.WRAP_CONTENT);

        if (idReference != 0) {
            params.addRule(RelativeLayout.BELOW, idReference);
            params.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
        }

        params.setMargins(0, margin, 0, 0);

        return params;
    }

    public void onClick(View v) {
        if (v.getId() == _returnBtn.getId()) {
            this.finish();
        }
    }
}
