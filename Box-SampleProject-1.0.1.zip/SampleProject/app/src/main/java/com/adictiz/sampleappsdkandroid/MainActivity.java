package com.adictiz.sampleappsdkandroid;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.adictiz.box.BWebviewOptions;
import com.adictiz.box.Box;
import com.adictiz.box.BoxRequestListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends Activity implements View.OnClickListener, BoxRequestListener {

    /****************************************
     * To get your mediaKey and your apiKey contact us at contact@adictiz.com
     ***************************************/

    public static String mediaKey = "o99jfyypiz";
    public static String campaignID = "";
    public static String apiKey = "";

    /****************************************
     * BUILD VIEW
     ***************************************/

    private int _deviceWidth;
    private int _deviceHeight;

    private RelativeLayout _titleBar;
    private TextView _title;

    private TextView _label1;
    private TextView _label2;
    private TextView _label3;
    private TextView _label4;

    private Button _webViewBtn;
    private Button _postUserBtn;
    private Button _bannerBtn;
    private Button _bannersListBtn;

    private boolean _isReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        _deviceWidth = metrics.widthPixels;
        _deviceHeight = metrics.heightPixels;

        _titleBar = (RelativeLayout) findViewById(R.id.relativeLayout);
        _titleBar.getLayoutParams().height = (int) (_deviceHeight * 0.1);
        _titleBar.getLayoutParams().width = _deviceWidth;
        _title = (TextView) findViewById(R.id.title);
        _title.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.1));

        _label1 = (TextView) findViewById(R.id.label1);
        _label1.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));
        _label2 = (TextView) findViewById(R.id.label2);
        _label2.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));
        _label3 = (TextView) findViewById(R.id.label3);
        _label3.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));
        _label4 = (TextView) findViewById(R.id.label4);
        _label4.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));

        _webViewBtn = (Button) findViewById(R.id.wbviewBtn);
        _webViewBtn.getLayoutParams().width = (int) (_deviceWidth * 0.5);
        _webViewBtn.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));
        _webViewBtn.setOnClickListener(this);

        _postUserBtn = (Button) findViewById(R.id.postUserBtn);
        _postUserBtn.getLayoutParams().width = (int) (_deviceWidth * 0.5);
        _postUserBtn.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));
        _postUserBtn.setOnClickListener(this);

        _bannerBtn = (Button) findViewById(R.id.bannerBtn);
        _bannerBtn.getLayoutParams().width = (int) (_deviceWidth * 0.5);
        _bannerBtn.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));
        _bannerBtn.setOnClickListener(this);

        _bannersListBtn = (Button) findViewById(R.id.bannersListBtn);
        _bannersListBtn.getLayoutParams().width = (int) (_deviceWidth * 0.5);
        _bannersListBtn.setTextSize(TypedValue.COMPLEX_UNIT_PX, (int) (_deviceWidth * 0.06));
        _bannersListBtn.setOnClickListener(this);

        _label1.setLayoutParams(generateLayoutParam(true, false, 0, (int) (_deviceHeight * .02)));
        _label2.setLayoutParams(generateLayoutParam(true, false, _webViewBtn.getId(), (int) (_deviceHeight * .02)));
        _label3.setLayoutParams(generateLayoutParam(true, false, _postUserBtn.getId(), (int) (_deviceHeight * .02)));
        _label4.setLayoutParams(generateLayoutParam(true, false, _bannerBtn.getId(), (int) (_deviceHeight * .02)));

        _webViewBtn.setLayoutParams(generateLayoutParam(false, false, _label1.getId(), (int) (_deviceHeight * .03)));
        _postUserBtn.setLayoutParams(generateLayoutParam(false, false, _label2.getId(), (int) (_deviceHeight * .03)));
        _bannerBtn.setLayoutParams(generateLayoutParam(false, false, _label3.getId(), (int) (_deviceHeight * .03)));
        _bannersListBtn.setLayoutParams(generateLayoutParam(false, false, _label4.getId(), (int) (_deviceHeight * .03)));

        /****************************************
         * BOX SDK INTEGRATION
         ***************************************/

        // Displaying log
        Box.setDebugMode(true);

        // Box SDK Initialization
        Box.initialize(this, MainActivity.mediaKey);

        // Customizing the navigation bar
        BWebviewOptions options = new BWebviewOptions();
        options.setNavigationBarTitleVisible(true);
        options.setNavigationBarButtonsColor(Color.WHITE);
        options.setNavigationBarTitleColor(Color.WHITE);
        options.setNavigationLoadingBarColor(Color.WHITE);
        options.setNavigationBarBackgroundColor(Color.parseColor("#008cc8"));
        Box.setWebviewOptions(options);

        // Retrieving Box campaigns list
        Box.getCampaignsList(this);
    }

    /****************************************
     * BOX SDK CALLBACKS
     ***************************************/

    @Override
    public void onGetCampaignsListSuccess(String response) {

        // Parsing the response and retrieving the first live campaign
        try {
            JSONArray jsonArray = new JSONArray(response);

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj1 = jsonArray.getJSONObject(i);

                if (obj1.get("status").toString().equals("live")) {
                    campaignID = obj1.get("id").toString();
                    _isReady = true;
                    break;
                }
            }

            if (!_isReady)
                Log.w("SP : SDK BOX", "No live campaign was found");

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    //NOT USED
    @Override
    public void onGetCampaignsListFailure(String s) {

    }

    @Override
    public void onPostUserFormSuccess(String s) {

    }

    @Override
    public void onPostUserFormFailure(String s) {

    }

    @Override
    public void onPostPictureResult(boolean b) {

    }

    @Override
    public void onGetPicturesListSuccess(String s) {

    }

    @Override
    public void onGetPicturesListFailure(String s) {

    }

    /****************************************
     * BUILD VIEW (METHODS)
     ***************************************/

    public RelativeLayout.LayoutParams generateLayoutParam(boolean isMatchParent_w, boolean isMatchParent_h, int idReference, int margin) {

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(isMatchParent_w ? RelativeLayout.LayoutParams.MATCH_PARENT : (int) (_deviceWidth * 0.5),
                isMatchParent_h ? RelativeLayout.LayoutParams.MATCH_PARENT : RelativeLayout.LayoutParams.WRAP_CONTENT);

        if (idReference != 0) {
            params.addRule(RelativeLayout.BELOW, idReference);
            params.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
        }

        params.setMargins(0, margin, 0, 0);

        return params;
    }

    @Override
    public void onClick(View v) {

        if (!_isReady)
            Log.w("SP : SDK BOX", "the Box SDK is not ready yet");

        if (v.getId() == _webViewBtn.getId()) {
            Box.showCampaign(campaignID);
        } else if (v.getId() == _bannerBtn.getId()) {
            startActivity(new Intent(this, BannerView.class));
        } else if (v.getId() == _bannersListBtn.getId()) {
            startActivity(new Intent(this, BannersListView.class));
        } else if (v.getId() == _postUserBtn.getId()) {
            startActivity(new Intent(this, PostUserView.class));
        }
    }
}
